<?php 

?>
<div class="wrap"> 
	<form action="" method="post">
	<label>Email</label>
	<input type="email" name="email" value="<?php echo get_option('agencybuilderwp_email'); ?>">
	<label>License Key</label>
	<?php if( !empty(get_option('agencybuilderwp_activated')) && get_option('agencybuilderwp_activated') == 'yes' ){ ?>
		<?php 
			$counts = strlen( get_option('agencybuilderwp_license') ) / 2;
		?>
		<input id="agencybuilderwp-license" type="text" name="license" value="<?php echo substr_replace( get_option('agencybuilderwp_license') ,"*************", $counts ); ?>">

	<?php }else{ ?>
		<input id="agencybuilderwp-license" type="text" name="license" value="<?php echo get_option('agencybuilderwp_license'); ?>">
	<?php } ?>
<!-- 
	<p>Enter the license key to use shortcodes.</p> -->
	<p class="authorization-btn">
	<?php if( !empty(get_option('agencybuilderwp_activated')) && get_option('agencybuilderwp_activated') == 'yes' ){ ?>
		<button id="agencybuilderwp-btn-change" type="button">Change</button>
	<?php }else{ ?>
		<button type="submit" name="authorize">Authorize</button>
	<?php } ?>
	</p> 
</form>
</div>


