<?php 

/*
   Plugin Name: AB Dev
   Description: Plugin for  Agency Builder Dev WP
   Version: 2.3.0
   Author: AgencyBuilderDev
*/

defined('ABSPATH') or die('This file is not accessible!');

class AgencyBuilderShortcodes
{
	private $result; 
	function __construct(){
		$this->result = $this->abshortcode_get_data();
		add_filter( 'twentytwenty_site_logo', 'do_shortcode');
		add_filter( 'single_post_title', 'do_shortcode' );
		add_filter( 'wp_head', 'do_shortcode' );
		add_filter( 'wp_title', 'do_shortcode' );
		add_filter( 'the_content', 'do_shortcode');
		add_filter( 'the_title', 'do_shortcode' );
		add_filter( 'widget_text', 'do_shortcode' );
		add_filter( 'widget_title', 'do_shortcode' );
		add_filter( 'list_cats', 'do_shortcode' );
		add_filter( 'wp_tag_cloud', 'do_shortcode' );
		add_filter( 'wptf_the_content', 'do_shortcode' );
		add_filter( 'bloginfo', 'do_shortcode' );
		add_filter( 'wp_nav_menu_items', 'do_shortcode' );
		add_filter( 'wp_new_user_notification_email','do_shortcode' );
		
		add_filter( 'elementor/widget/render_content', 'do_shortcode' );
		add_filter( 'elementor_pro/widget/render_content', 'do_shortcode' );
		add_filter( 'elementor/frontend/the_content', 'do_shortcode' );
		add_filter( 'elementor/widget/form', 'do_shortcode' );
		add_filter( 'elementor/element/print_template', 'do_shortcode' );
		add_filter( 'elementor_pro/dynamic_tags/shortcode/should_escape', '__return_false' ); 
		add_filter( 'widget_text', 'do_shortcode', 11 );
		
		add_filter( 'elementor/frontend/builder_content_data','do_shortcode' );

		add_filter( 'elementor_pro/forms/wp_mail_headers', 'do_shortcode' );
		add_filter( 'elementor_pro/forms/wp_mail_message', 'do_shortcode' );
		
		add_filter( ' elementor/admin/create_new_post/meta ', 'do_shortcode' );
		add_action( 'elementor/widget/before_render_content', 'do_shortcode' );
		add_filter('elementor/admin/dashboard_overview_widget/footer_actions','do_shortcode');
		add_filter('elementor/api/get_templates/body_args','do_shortcode');
		add_filter('elementor/core/responsive/get_stylesheet_templates','do_shortcode');
		add_filter('elementor/document/urls/edit','do_shortcode');
		add_filter('elementor/document/urls/exit_to_dashboard','do_shortcode');
		add_filter('elementor/document/urls/preview','do_shortcode');
		add_filter('elementor/document/urls/wp_preview','do_shortcode');
		add_filter('elementor/documents/ajax_save/return_data','do_shortcode');
		add_filter('elementor/documents/get/post_id','do_shortcode');
		add_filter('elementor/editor/localize_settings','do_shortcode');
		add_filter('elementor/editor/user/restrictions','do_shortcode');
		add_filter('elementor/element/get_child_type','do_shortcode');
		add_filter('elementor/fonts/additional_fonts','do_shortcode');
		add_filter('elementor/fonts/groups','do_shortcode');
		add_filter('elementor/frontend/builder_content_data','do_shortcode');
		add_filter('elementor/frontend/print_google_fonts','do_shortcode');
		add_filter('elementor/frontend/the_content','do_shortcode');
		add_filter('elementor/schemes/enabled_schemes','do_shortcode');
		add_filter('elementor/settings/{$settings_name}/success_response_data','do_shortcode');
		add_filter('elementor/shapes/additional_shapes','do_shortcode');
		add_filter('elementor/template-library/create_new_dialog_types','do_shortcode');
		add_filter('elementor/template-library/get_template','do_shortcode');
		add_filter('elementor/template-library/get_template_label_by_type','do_shortcode');
		add_filter('elementor/template_library/is_template_supports_export','do_shortcode');
		add_filter('elementor/template_library/sources/local/register_post_type_args','do_shortcode');
		add_filter('elementor/template_library/sources/local/register_taxonomy_args','do_shortcode');
		add_filter('elementor/tracker/admin_description_text','do_shortcode');
		add_filter('elementor/tracker/last_send_interval','do_shortcode');
		add_filter('elementor/tracker/last_send_time','do_shortcode');
		add_filter('elementor/tracker/send_override','do_shortcode');
		add_filter('elementor/tracker/send_tracking_data_params','do_shortcode');
		add_filter('elementor/utils/get_edit_link','do_shortcode');
		add_filter('elementor/utils/get_placeholder_image_src','do_shortcode');
		add_filter('elementor/utils/is_post_support','do_shortcode');
		add_filter('elementor/utils/is_post_type_support','do_shortcode');
		add_filter('elementor/utils/preview_url','do_shortcode');
		add_filter('elementor/utils/wp_preview_url','do_shortcode');
		add_filter('elementor/widget/render_content','do_shortcode');
		add_filter('elementor/widgets/black_list','do_shortcode');
		add_filter('elementor/widgets/wordpress/widget_args','do_shortcode');
		add_filter('elementor/{$element_type}/print_template','do_shortcode');
		add_filter('elementor/{$settings_name}/settings/success_response_data','do_shortcode');
		add_filter('image_size_names_choose','do_shortcode');
		add_filter('oembed_result','do_shortcode');
		add_filter('widget_text','do_shortcode');
		
		// add_action( 'init', array($this, 'add_post_type'));
		add_action('admin_menu', array($this, 'abShortcodesThemeOptions'));
		add_action ('init', array($this, 'abshortcode_redirect'));
		add_action( 'admin_init', array($this, 'abshortcode_new_option'));
		
		add_action ('init', array($this, 'putCookie'));

		add_filter('pre_get_document_title', array($this, 'agencyBuilder_the_title'));	
		add_filter( 'document_title_parts', array($this, 'agencyBuilder_header_title_function'));   //own function for HTML/Browser title	

		add_action('init', array($this, 'register_script'));

		$data = $this->result;
		foreach($data as $key => $value){
			add_shortcode( 'AgencyBuilder_'.$key, function ($atts) use ($value){
                if (preg_match('/(\.jpg|\.jpeg|\.png|\.bmp)$/i', $value)) {
                    return '<img src="https://agencybuilderdev.io/storage/'.$value.'" />';
                 } else{
                     return $value;
                 }
			});
		}
	}
	
	function register_script() {
	    // wp_register_script( 'custom_jquery', plugins_url('/js/custom-jquery.js', __FILE__), array('jquery'), '2.5.1' );
	    //wp_register_style( 'abShortcodes_style', plugins_url('/css/style.css', __FILE__), false, '1.0.0', 'all');
	    wp_enqueue_style( 'abShortcodes_style', plugins_url('/css/style.css', __FILE__), false, '1.0.0', 'all');
	}

	function agencyBuilder_header_title_function($title) {
	    if (isset($title['title'])) $title['title'] = do_shortcode($title['title']);
	    if (isset($title['page'])) $title['page'] = do_shortcode($title['page']);
	    if (isset($title['tagline'])) $title['tagline'] = do_shortcode($title['tagline']);
	    if (isset($title['site'])) $title['site'] = do_shortcode($title['site']);
	    return $title;
	}
	function agencyBuilder_the_title($title) {
	    return do_shortcode($title);
	}
	function activate(){
		 $this->abShortcodesThemeOptions();		
		flush_rewrite_rules();
	}
	function abShortcodesThemeOptions(){
		add_menu_page( 'abs-option-settings', 			// page title
			'Agency Builder Settings Dev',					// Menu title
			'manage_options',							// capability
			'abs-option-settings',						// menu slug
			array($this, 'abshortcode_theme_option'),	// callback function
			'dashicons-admin-network'					// icon
		);
	}
	
	function putCookie(){
		if(isset($_GET['business_code'] ) ) {
			unSet($_COOKIE['business_code']);
		    if (!isset($_COOKIE['business_code'])) {
		        setcookie( 'business_code' , $_GET['business_code'], strtotime( '+30 days' ), '/' , $_SERVER['SERVER_NAME'], 0 );
		    }
		} 
	}  

	function abshortcode_get_data(){
		if (get_option( 'abshortcode_license_key' )) {
			$business_code = "";
			if(isset($_COOKIE['business_code'])) {
				$business_code = $_COOKIE['business_code'];
				}
				if(isset($_GET['business_code'] ) ) {
					$business_code =  $_GET['business_code'];
				}

				$access_token = get_option( 'abshortcode_license_key' ); 
			    // use above token to make further api calls in this session or until the access token expires
			    $ch = curl_init();
			    $url = 'https://app.agencybuilderdev.io/api/v1/user/resources';
			    $header = array(
			    'Authorization: Bearer '. $access_token,
			    'URL: '. admin_url('admin.php?page=abs-option-settings&response_type=code&scope='),
			    'Code: '. $business_code ,
			    );
			    
			    curl_setopt($ch,CURLOPT_URL, $url );
			    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			    curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
			    $result = curl_exec($ch);
			    curl_close($ch);
			    
			    $response = json_decode($result);
			    if($response){
				    return $response;
			    }else{
			    	return null;
			    }
		}
	}

	function abshortcode_theme_option(){				
	?>
		
		<div class="agencybuilderwp-form-wrap">
			<h2>Agency Builder Settings</h2>
			<?php if (get_option( 'abshortcode_license_key' )) { ?>
				<div style="display: flex; ">
					<h3>Status:
						<span style="color: #008000; font-style: italic;">Active</span>					
					</h3>
				</div>
					<div style="display: flex;">
						<div style="align-self: flex-start; margin-right: 5px;">
							<a class="button" href="https://app.agencybuilderdev.io/dashboard">Visit My Account</a>
						</div>
						<div style="align-self: flex-start;">

							<a class="button" href="https://app.agencybuilderdev.io/api/deactivate/?request_url=<?php echo get_site_url(); ?>">Disconnect</a>
						</div>
					</div>
			<?php } else{ ?>
				<small>
					<a class="button" href="https://app.agencybuilderdev.io/api/activate/?request_url=<?php echo get_site_url(); ?> ">Activate</a>
				</small>
			<?php } ?>
		</div>
	<?php
	}

	function abshortcode_new_option() {
	    if ( isset( $_POST['abshortcode_new_option'] )|| isset( $_GET['abshortcode_deactivation'] ) ) {
	        delete_option( 'abshortcode_license_key' );
	    }
	}

	function abshortcode_redirect() {		
	    if( isset( $_GET['code'] ) ) {
	        if (FALSE === get_option('abshortcode_license_key')){
	        	add_option('abshortcode_license_key', $_GET['code']);
	        }else{
	        	update_option( 'abshortcode_license_key', $_GET['code'], 'yes' );
	        }
	        wp_safe_redirect( admin_url('admin.php?page=abs-option-settings') );
	        exit;
	    }
	} 

	function deactivate(){
	}
	function uninstall(){
		
	}
}

if (class_exists('AgencyBuilderShortcodes')) {
	$agencyBuilderShortcodes = new AgencyBuilderShortcodes();
}

// activation
register_activation_hook(__FILE__, array($agencyBuilderShortcodes, 'activate'));

// deactivation
register_activation_hook(__FILE__, array($agencyBuilderShortcodes, 'deactivate'));

// uninstall
//register_uninstall_hook(__FILE__, array($agencyBuilderShortcodes, 'uninstall'));